### Maintainability Badge:
<a href="https://codeclimate.com/github/NataliSnail/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/8f1fb33fc3367e8144fa/maintainability" /></a>
